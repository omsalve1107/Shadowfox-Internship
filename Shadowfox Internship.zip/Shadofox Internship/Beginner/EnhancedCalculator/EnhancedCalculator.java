import java.util.Scanner;

public class EnhancedCalculator {

    // Scanner for input
    static Scanner sc = new Scanner(System.in);

    // ===== Arithmetic Operations =====
    public static void arithmeticMenu() {
        System.out.println("\n--- Arithmetic Operations ---");
        System.out.println("1. Addition");
        System.out.println("2. Subtraction");
        System.out.println("3. Multiplication");
        System.out.println("4. Division");
        System.out.print("Choose an option: ");
        int choice = sc.nextInt();

        try {
            System.out.print("Enter first number: ");
            double a = sc.nextDouble();
            System.out.print("Enter second number: ");
            double b = sc.nextDouble();

            switch (choice) {
                case 1: System.out.println("Result: " + (a + b)); break;
                case 2: System.out.println("Result: " + (a - b)); break;
                case 3: System.out.println("Result: " + (a * b)); break;
                case 4: 
                    if (b == 0) throw new ArithmeticException("Cannot divide by zero!");
                    System.out.println("Result: " + (a / b)); 
                    break;
                default: System.out.println("Invalid option!");
            }
        } catch (Exception e) {
            System.out.println("Error: Invalid input. " + e.getMessage());
            sc.nextLine(); // clear buffer
        }
    }

    // ===== Scientific Functions =====
    public static void scientificMenu() {
        System.out.println("\n--- Scientific Functions ---");
        System.out.println("1. Square Root");
        System.out.println("2. Power");
        System.out.println("3. Sine");
        System.out.println("4. Cosine");
        System.out.println("5. Tangent");
        System.out.println("6. Logarithm (base e)");
        System.out.print("Choose an option: ");
        int choice = sc.nextInt();

        try {
            double x, y;
            switch (choice) {
                case 1:
                    System.out.print("Enter number: ");
                    x = sc.nextDouble();
                    System.out.println("Result: " + Math.sqrt(x));
                    break;
                case 2:
                    System.out.print("Enter base: ");
                    x = sc.nextDouble();
                    System.out.print("Enter exponent: ");
                    y = sc.nextDouble();
                    System.out.println("Result: " + Math.pow(x, y));
                    break;
                case 3:
                    System.out.print("Enter angle in radians: ");
                    x = sc.nextDouble();
                    System.out.println("Result: " + Math.sin(x));
                    break;
                case 4:
                    System.out.print("Enter angle in radians: ");
                    x = sc.nextDouble();
                    System.out.println("Result: " + Math.cos(x));
                    break;
                case 5:
                    System.out.print("Enter angle in radians: ");
                    x = sc.nextDouble();
                    System.out.println("Result: " + Math.tan(x));
                    break;
                case 6:
                    System.out.print("Enter number: ");
                    x = sc.nextDouble();
                    System.out.println("Result: " + Math.log(x));
                    break;
                default:
                    System.out.println("Invalid option!");
            }
        } catch (Exception e) {
            System.out.println("Error: Invalid input. " + e.getMessage());
        }
    }

    // ===== Unit Conversions =====
    public static void conversionMenu() {
        System.out.println("\n--- Unit Conversions ---");
        System.out.println("1. Temperature (C <-> F <-> K)");
        System.out.println("2. Currency (INR <-> USD)");
        System.out.println("3. Distance (Km <-> Miles)");
        System.out.print("Choose an option: ");
        int choice = sc.nextInt();

        switch (choice) {
            case 1: temperatureConversion(); break;
            case 2: currencyConversion(); break;
            case 3: distanceConversion(); break;
            default: System.out.println("Invalid option!");
        }
    }

    // Temperature Conversion
    public static void temperatureConversion() {
        System.out.println("\n--- Temperature Conversion ---");
        System.out.println("1. Celsius to Fahrenheit");
        System.out.println("2. Fahrenheit to Celsius");
        System.out.println("3. Celsius to Kelvin");
        System.out.println("4. Kelvin to Celsius");
        int choice = sc.nextInt();

        double temp;
        switch (choice) {
            case 1:
                System.out.print("Enter Celsius: ");
                temp = sc.nextDouble();
                System.out.println("Fahrenheit: " + ((temp * 9 / 5) + 32));
                break;
            case 2:
                System.out.print("Enter Fahrenheit: ");
                temp = sc.nextDouble();
                System.out.println("Celsius: " + ((temp - 32) * 5 / 9));
                break;
            case 3:
                System.out.print("Enter Celsius: ");
                temp = sc.nextDouble();
                System.out.println("Kelvin: " + (temp + 273.15));
                break;
            case 4:
                System.out.print("Enter Kelvin: ");
                temp = sc.nextDouble();
                System.out.println("Celsius: " + (temp - 273.15));
                break;
            default:
                System.out.println("Invalid option!");
        }
    }

    // Currency Conversion (fixed rate)
    public static void currencyConversion() {
        System.out.println("\n--- Currency Conversion (1 USD = 83 INR approx) ---");
        System.out.println("1. INR to USD");
        System.out.println("2. USD to INR");
        int choice = sc.nextInt();

        double amount;
        switch (choice) {
            case 1:
                System.out.print("Enter INR: ");
                amount = sc.nextDouble();
                System.out.println("USD: " + (amount / 83));
                break;
            case 2:
                System.out.print("Enter USD: ");
                amount = sc.nextDouble();
                System.out.println("INR: " + (amount * 83));
                break;
            default:
                System.out.println("Invalid option!");
        }
    }

    // Distance Conversion
    public static void distanceConversion() {
        System.out.println("\n--- Distance Conversion ---");
        System.out.println("1. Km to Miles");
        System.out.println("2. Miles to Km");
        int choice = sc.nextInt();

        double dist;
        switch (choice) {
            case 1:
                System.out.print("Enter Km: ");
                dist = sc.nextDouble();
                System.out.println("Miles: " + (dist * 0.621371));
                break;
            case 2:
                System.out.print("Enter Miles: ");
                dist = sc.nextDouble();
                System.out.println("Km: " + (dist / 0.621371));
                break;
            default:
                System.out.println("Invalid option!");
        }
    }

    // ===== Main Menu =====
    public static void main(String[] args) {
        int choice;
        do {
            System.out.println("\n==== Enhanced Console Calculator ====");
            System.out.println("1. Arithmetic Operations");
            System.out.println("2. Scientific Functions");
            System.out.println("3. Unit Conversions");
            System.out.println("4. Exit");
            System.out.print("Choose an option: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1: arithmeticMenu(); break;
                case 2: scientificMenu(); break;
                case 3: conversionMenu(); break;
                case 4: System.out.println("Exiting Calculator. Goodbye!"); break;
                default: System.out.println("Invalid option!");
            }
        } while (choice != 4);

        sc.close();
    }
}
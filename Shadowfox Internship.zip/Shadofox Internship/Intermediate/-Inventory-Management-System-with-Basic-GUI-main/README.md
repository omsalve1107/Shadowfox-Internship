# -Inventory-Management-System-with-Basic-GUI
You compile and run using:

javac *.java
java InventoryManagementSystem


Swing launches a window (JFrame) titled Inventory Management System.

The window contains:

A table showing your inventory.

Three buttons — Add Item, Update Item, Delete Item.
#) InventoryManagementSystem.java — Main GUI
